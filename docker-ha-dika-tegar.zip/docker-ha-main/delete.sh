#!/bin/bash

docker stack rm widan
